﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebShopCleanCode
{
    public class Button
    {
        public string Name { get; set; }
        public Button(string name)
        {
            Name = name;
        }
    }
}
